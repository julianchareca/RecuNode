import express from "express";
import service from "./preguntaService.js";

const app = express();

const services = new service;

app.post("/preguntas", async (req, res) => {
    await services.crearPregunta(req.body.pregunta);
    res.status(200).json("Listo");
})

app.put("/preguntas", async (req, res) => {
    await services.actualizarPregunta(req.body.pregunta);
    res.status(200).json("Listo");
})

app.delete("/preguntas", async (req, res) => {
    await services.eliminarPregunta(req.body.preguntaId);
    res.status(200).json("Listo");
})

app.get("   ", async (req, res) => {
    let preguntas = await services.getAllPreguntas();
    let numero = Math.floor(Math.random() * preguntas.length);
    res.status(200).json(preguntas[numero]);
})

app.get("/preguntas", async (req, res) => {
    let preguntas = await services.getAllPreguntas();
    res.status(200).json(preguntas);
})


app.post("/respuestas", async (req, res) => {
    await services.crearRespuesta(req.body.respuesta);
    res.status(200).json("Listo");
})
app.listen(3000, ()=>{
    console.log('Listening on port 3000');
})